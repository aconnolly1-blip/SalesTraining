window.InitUserScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
window.Script26 = function()
{
  var player = GetPlayer();
var current = player.GetVar("SecondTryScore");
player.SetVar("SecondTryScore", current + 0.5);
}

window.Script27 = function()
{
  var player = GetPlayer();
var current = player.GetVar("SecondTryScore");
player.SetVar("SecondTryScore", current + 0.5);
}

window.Script28 = function()
{
  var player = GetPlayer();
var current = player.GetVar("SecondTryScore");
player.SetVar("SecondTryScore", current + 0.5);
}

window.Script29 = function()
{
  var player = GetPlayer();
var current = player.GetVar("SecondTryScore");
player.SetVar("SecondTryScore", current + 0.5);
}

window.Script30 = function()
{
  var player = GetPlayer();
var current = player.GetVar("SecondTryScore");
player.SetVar("SecondTryScore", current + 0.5);
}

window.Script31 = function()
{
  var player = GetPlayer();
var current = player.GetVar("SecondTryScore");
player.SetVar("SecondTryScore", current + 0.5);
}

};
